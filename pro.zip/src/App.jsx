import Template from "./Templates/Template";
function app() {
  return (
    <>
      <Template />
    </>
  );
}

export default app;
